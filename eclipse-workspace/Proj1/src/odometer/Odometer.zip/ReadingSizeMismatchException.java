package odometer;

public class ReadingSizeMismatchException extends ReadingException{
	
	public ReadingSizeMismatchException(String message) {
		super(message);
	}

}