package odometer;
public class ReadingException extends Exception{
	public ReadingException(String message) {
		super(message);
	}
}