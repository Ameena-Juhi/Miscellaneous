package odometer;

public class NonAscendingReadingException extends ReadingException{
	
	public NonAscendingReadingException(String message) {
		super(message);
	}
	
}